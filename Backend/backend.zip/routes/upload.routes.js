const express = require("express");
const router = express.Router();
const SingleFileUpload = require("../middleware/SingleFIleUpload");

router.post("/single", SingleFileUpload, (req, res) => {
  res.status(201).json({ url: req.filelink });
});

module.exports = uploadRoutes = router;
