const { DataTypes: types } = require("sequelize");
const sequelize = require("../database/connection");
const Gateway = require("./Gateway");
const Review = require("./Review");

const Exchange = sequelize.define("Exchange", {
  order_id: {
    type: types.STRING,
  },

  exchange_rate: {
    type: types.STRING,
  },

  sent_wallet: {
    type: types.STRING,
  },

  sent_details: {
    type: types.STRING,
  },

  receive_wallet: {
    type: types.STRING,
  },

  sent_amount: {
    type: types.INTEGER,
  },

  receive_amount: {
    type: types.INTEGER,
  },

  status: {
    type: types.STRING,
    defaultValue: "pending",
  },
});

Exchange.belongsTo(Gateway, {
  as: "sentGateway",
  foreignKey: "sent_gateway_id",
});

Exchange.belongsTo(Gateway, {
  as: "receiveGateway",
  foreignKey: "receive_gateway_id",
});

Exchange.hasOne(Review, { foreignKey: "exchange_id" });
Review.belongsTo(Exchange, { as: "exchange", foreignKey: "exchange_id" });

module.exports = Exchange;
