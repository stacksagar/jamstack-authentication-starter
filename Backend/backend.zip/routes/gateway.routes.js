const all_gateways = require("../controller/gateways/all_gateways");
const create_gateway = require("../controller/gateways/create_gateway");
const single_gateway = require("../controller/gateways/single_gateway");
const update_gateway = require("../controller/gateways/update_gateway");
const delete_gateway = require("../controller/gateways/delete_gateway");
const SingleFileUpload = require("../middleware/SingleFIleUpload");
const requireRole = require("../middleware/requireRole");
const verifyJWT = require("../middleware/verifyJWT");

const roles = require("../config/roles");

const router = require("express").Router();

router.post("/create", SingleFileUpload, create_gateway);

router.get("/all", all_gateways);

router.get("/single/:id", single_gateway);
router.put("/update/:id", verifyJWT, requireRole(roles.admin), update_gateway);
router.delete("/delete/:id", verifyJWT, requireRole(roles.admin), delete_gateway);

module.exports = gatewayRoutes = router;