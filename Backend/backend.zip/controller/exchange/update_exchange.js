const SendEmailWithCpanelCredential = require("../../email/SendEmailWithCpanelCredential");
const exchange_completed_html = require("../../email/templates/exchange_completed_html");
const Exchange = require("../../models/Exchange");
const Gateway = require("../../models/Gateway");
const User = require("../../models/User");

module.exports = update_exchange = async (req, res, next) => {
  try {
    await Exchange.update(req.body, {
      where: { id: req.query.id },
    });

    const exchange = await Exchange.findOne({
      where: { id: req.query.id },
      include: [
        {
          model: Gateway,
          as: "sentGateway",
          attributes: ["id", "name", "currency"],
        },
        {
          model: Gateway,
          as: "receiveGateway",
          attributes: ["id", "name", "currency"],
        },
        { model: User, as: "user", attributes: ["id", "name", "email"] },
      ],
    });

    if (req.body?.status === "completed") {
      const html = await exchange_completed_html({
        user_name: exchange.dataValues?.user?.name,
        order_id: exchange.dataValues?.order_id,
        exchange_rate: exchange.dataValues?.exchange_rate,
        sent_wallet: exchange.dataValues?.sent_wallet,
        sent_details: exchange.dataValues?.sent_details,
        receive_wallet: exchange.dataValues?.receive_wallet,
        sent_amount: `${exchange.dataValues?.sent_amount} ${exchange.dataValues?.sentGateway?.currency}`,
        receive_amount: `${exchange.dataValues?.receive_amount} ${exchange.dataValues?.receiveGateway?.currency}`,
      });

      await SendEmailWithCpanelCredential(
        exchange.dataValues?.user?.email,
        "Your order has been approved!",
        html
      );
    }

    res.status(200).json({ message: "Exchange Updated!" });
  } catch (error) {
    next(error);
  }
};
