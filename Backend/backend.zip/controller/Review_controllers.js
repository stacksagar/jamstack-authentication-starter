const Exchange = require("../models/Exchange");
const Review = require("../models/Review");
const User = require("../models/User");

class Review_controller {
  async create(req, res, next) {
    try {
      const review = await Review.create(req.body);
      res.status(201).json({ review });
    } catch (error) {
      next(error);
    }
  }

  async read(req, res, next) {
    try {
      const user_id = Number(req?.query?.user_id || req?.body?.id);
      const limit = Number(req?.query?.limit);
      const page = Number(req?.query?.page);

      const sort = req?.query?.sort;
      const order = req?.query?.order;

      const sortBy = (typeof sort === "object" ? sort[0] : sort || "")
        ?.toLowerCase()
        ?.trim();

      const orderBy = (typeof order === "object" ? order[0] : order || "")
        ?.toLowerCase()
        ?.trim();

      const offset = limit * (page - 1);

      const conditions = {
        where: {},
        order: [],
        include: [
          { model: User, as: "user", attributes: ["id", "name"] },
          {
            model: Exchange,
            as: "exchange",
            attributes: ["order_id", "exchange_rate"],
          },
        ],
      };

      if (user_id) {
        conditions.where.user_id = user_id;
      }

      if (page && limit) {
        conditions.offset = offset;
        conditions.limit = limit;
      }

      if (
        sortBy === "id" &&
        (orderBy === "ascending" || orderBy === "descending")
      ) {
        conditions.order.push([
          sortBy,
          orderBy === "ascending" ? "ASC" : "DESC",
        ]);
      }

      const reviews = await Review.findAndCountAll({
        ...conditions,
      });

      res.status(201).json({
        totalPages: Math.ceil(reviews.count / limit),
        totalItems: reviews.count,
        currentPage: page,
        reviews: reviews.rows,
      });
    } catch (error) {
      next(error);
    }
  }

  async readSingle(req, res, next) {
    try {
      const review = await Review.findOne({
        where: { id: req.params?.id || 0 },
      });

      res.status(200).json({ review });
    } catch (error) {
      next(error);
    }
  }

  async update(req, res, next) {
    try {
      await Review.update(req.body, { where: { id: req.params?.id || "0" } });
      const review = await Review.findOne({
        where: { id: req.params?.id || "0" },
      });

      res.status(200).json({ review });
    } catch (error) {
      next(error);
    }
  }

  async delete(req, res, next) {
    try {
      const deleted = await Review.findOne({
        where: { id: req.params?.id || "0" },
      });
      await Review.destroy({ where: { id: req.params?.id || "0" } });

      res.status(200).json({ deleted });
    } catch (error) {
      next(error);
    }
  }
}

module.exports = new Review_controller();
