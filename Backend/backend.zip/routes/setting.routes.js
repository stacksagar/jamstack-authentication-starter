const express = require("express");
const Setting_controllers = require("../controller/Setting_controllers");
const router = express.Router();

router.post("/", Setting_controllers.create);
router.get("/", Setting_controllers.read);
router.put("/", Setting_controllers.update);
router.delete("/", Setting_controllers.delete);

router.put("/reset-unseen-exchange", Setting_controllers.reset_unseen_exchang);

module.exports = uploadRoutes = router;
