const Exchange = require("../../models/Exchange");
const { uid } = require("uid");
const Gateway = require("../../models/Gateway");
const User = require("../../models/User");

const SendEmailWithCpanelCredential = require("../../email/SendEmailWithCpanelCredential");
const exchange_create_html = require("../../email/templates/exchange_create_html");
const Setting = require("../../models/Setting");

module.exports = create_exchange = async (req, res, next) => {
  const {
    exchange_rate,
    sent_wallet,
    sent_details,
    receive_wallet,
    sent_amount,
    receive_amount,
    user_id,
    sent_gateway_id,
    receive_gateway_id,
    status,
  } = req.body;

  try {
    const exist = await Exchange.findOne({ where: { sent_details } });
    if (exist?.dataValues?.sent_details) next("Trx/Payment id exist!");

    const created = await Exchange.create({
      order_id: uid().toUpperCase(),
      exchange_rate,
      sent_wallet,
      sent_details,
      receive_wallet,
      sent_amount,
      receive_amount,
      sent_gateway_id,
      receive_gateway_id,
      user_id,
      status: status || "pending",
    });

    const user = await User.findOne({ where: { id: user_id } });
    const setting = await Setting.findOne({ where: { id: 1 } });
    const previous_unseen = Number(setting?.admin?.unseen_exchange || 0) || 0;
    await Setting.update(
      {
        admin: { ...setting?.admin, unseen_exchange: previous_unseen + 1 },
      },
      { where: { id: 1 } }
    );
    console.log("previous_unseen ", previous_unseen);

    const exchange = await Exchange.findOne({
      where: { id: created.dataValues.id },
      include: [
        {
          model: Gateway,
          as: "sentGateway",
          attributes: ["id", "name", "currency"],
        },
        {
          model: Gateway,
          as: "receiveGateway",
          attributes: ["id", "name", "currency"],
        },
        { model: User, as: "user", attributes: ["id", "name"] },
      ],
    });

    const html = await exchange_create_html({
      user_name: user.dataValues?.name,
      order_id: exchange.dataValues?.order_id,
      exchange_rate: exchange.dataValues?.exchange_rate,
      sent_wallet: exchange.dataValues?.sent_wallet,
      sent_details: exchange.dataValues?.sent_details,
      receive_wallet: exchange.dataValues?.receive_wallet,
      sent_amount: `${exchange.dataValues?.sent_amount} ${exchange.dataValues?.sentGateway?.currency}`,
      receive_amount: `${exchange.dataValues?.receive_amount} ${exchange.dataValues?.receiveGateway?.currency}`,
    });

    await SendEmailWithCpanelCredential(
      user.dataValues?.email,
      "Your order has been received!",
      html
    );

    res.status(201).json({ exchange });
  } catch (error) {
    next(error);
  }
};
