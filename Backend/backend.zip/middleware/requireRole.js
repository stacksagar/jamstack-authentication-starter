const roles = require("../config/roles");

const requireRole = (role_needed = roles.user | roles.editor | roles.admin) => {
  return (req, _res, next) => {
    if (req?.role >= role_needed) next();
    else return next(`You don't have permission to access!`);
  };
};

module.exports = requireRole;
