const { DataTypes: types } = require("sequelize");
const sequelize = require("../database/connection");
const Exchange = require("./Exchange");
const Review = require("./Review");

const User = sequelize.define("User", {
  name: {
    type: types.STRING,
    allowNull: false,
  },

  email: {
    type: types.STRING,
    allowNull: false,
    unique: true,
  },

  phone: {
    type: types.STRING,
    allowNull: false,
  },

  password: {
    type: types.STRING,
    allowNull: false,
  },

  username: {
    type: types.STRING,
  },

  picture: {
    type: types.STRING,
  },

  nid: {
    type: types.STRING,
  },

  refresh_token: {
    type: types.STRING,
  },

  access_token: {
    type: types.STRING,
  },

  role: types.ENUM(["1", "2", "3"]),

  disabled: {
    type: types.BOOLEAN,
  },

  isEmailVerified: {
    type: types.BOOLEAN,
  },
});

User.hasMany(Exchange, { foreignKey: "user_id" });
Exchange.belongsTo(User, {
  as: "user",
  foreignKey: "user_id",
});

User.hasMany(Review, {
  foreignKey: "user_id",
});
Review.belongsTo(User, {
  as: "user",
  foreignKey: "user_id",
});

module.exports = User;
