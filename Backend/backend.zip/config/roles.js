const roles = {
  user: 1,
  editor: 2,
  admin: 3,
};

module.exports = roles;
