const Gateway = require("../../models/Gateway");

module.exports = single_gateway = async (req, res, next) => {
  try {
    const gateways = await Gateway.findOne({
      where: {
        id: req.params.id,
      },
      attributes: req.body.attributes || null,
    });

    res.status(200).json({
      gateways,
    });
  } catch (error) {
    next(error);
  }
};
