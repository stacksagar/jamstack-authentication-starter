const express = require("express");
const Post_controllers = require("../controller/Post_controllers");
const router = express.Router();

router.post("/", Post_controllers.create);
router.get("/", Post_controllers.read);
router.get("/:slug", Post_controllers.readSinglePost);
router.put("/", Post_controllers.update);
router.delete("/", Post_controllers.delete);

module.exports = postRoutes = router;
