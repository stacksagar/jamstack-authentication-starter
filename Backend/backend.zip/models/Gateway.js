const { DataTypes: types } = require("sequelize");
const sequelize = require("../database/connection");

const Gateway = sequelize.define("Gateway", {
  name: {
    type: types.STRING,
    unique: true,
  },

  wallet: {
    type: types.STRING,
  },

  minimum: {
    type: types.INTEGER,
  },

  maximum: {
    type: types.INTEGER,
  },

  logo: {
    type: types.STRING,
  },

  currency: {
    type: types.STRING,
  },

  reserve: {
    type: types.INTEGER,
  },

  rates: {
    type: types.JSON,
  },
});

module.exports = Gateway;
