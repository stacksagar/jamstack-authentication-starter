const Gateway = require("../../models/Gateway");

module.exports = create_gateway = async (req, res, next) => {
  const { name, wallet, minimum, maximum, logo, currency, reserve, rates } =
    req.body;

  try {
    const isNameExist = await Gateway.findOne({ where: { name: name?.trim() } }); 
    if (isNameExist) return next("Gateway already exist!");

    const gateway = await Gateway.create({
      name: name?.trim(),
      wallet,
      minimum,
      maximum,
      currency,
      reserve,
      logo: req.filelink || logo,
      rates: rates || {},
    });

    const all = await Gateway.findAll({ attributes: ["id", "rates"] });

    all.forEach((g) => {
      const rates = JSON.parse(g.rates) || {};
      rates[gateway.id] = { sell: { from: 0, to: 0 } };
      if (gateway.id === g.id) return;
      (async () => {
        await Gateway.update(
          {
            rates,
          },
          { where: { id: g?.id } }
        );
      })();
    });

    res.status(201).json({ gateway });
  } catch (error) {
    next(error);
  }
};
