const express = require("express");
const Review_controllers = require("../controller/Review_controllers");
const router = express.Router();

router.post("/", Review_controllers.create);
router.get("/", Review_controllers.read);
router.get("/:id", Review_controllers.readSingle);
router.put("/:id", Review_controllers.update);
router.delete("/:id", Review_controllers.delete);

module.exports = reviewRoutes = router;
