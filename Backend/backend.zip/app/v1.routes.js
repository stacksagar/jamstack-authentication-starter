const router = require("express").Router();

const authRoutes = require("../routes/auth.routes");
const exchangeRoutes = require("../routes/exchange.routes");
const gatewayRoutes = require("../routes/gateway.routes");
const mailRoutes = require("../routes/mail.routes");
const pageRoutes = require("../routes/page.routes");
const reviewRoutes = require("../routes/review.routes");
const settingRoutes = require("../routes/setting.routes");
const uploadRoutes = require("../routes/upload.routes");
const postRoutes = require("../routes/post.routes");

router.get("/health", (_req, res) => {
  res.status(200).json({ message: "ok", success: true });
});

router.use("/auth", authRoutes);
router.use("/upload", uploadRoutes);
router.use("/gateway", gatewayRoutes);
router.use("/exchange", exchangeRoutes);
router.use("/settings", settingRoutes);
router.use("/mail", mailRoutes);
router.use("/page", pageRoutes);
router.use("/review", reviewRoutes);
router.use("/post", postRoutes);

module.exports = v1Routes = router;
