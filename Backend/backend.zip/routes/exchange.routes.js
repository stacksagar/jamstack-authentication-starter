const SingleFileUpload = require("../middleware/SingleFIleUpload");
const requireRole = require("../middleware/requireRole");
const verifyJWT = require("../middleware/verifyJWT");

const roles = require("../config/roles");
const create_exchange = require("../controller/exchange/create_exchange");
const all_exchanges = require("../controller/exchange/all_exchanges");
const update_exchange = require("../controller/exchange/update_exchange");
const delete_exchange = require("../controller/exchange/delete_exchange");

const router = require("express").Router();

router.get("/all", all_exchanges);
router.post("/create", verifyJWT, requireRole(roles.user), create_exchange);
router.put("/update", verifyJWT, requireRole(roles.admin), update_exchange);
router.delete("/delete", verifyJWT, requireRole(roles.admin), delete_exchange);

module.exports = exchangeRoutes = router;
