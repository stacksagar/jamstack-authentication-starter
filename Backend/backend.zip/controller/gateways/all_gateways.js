const Gateway = require("../../models/Gateway");

module.exports = all_gateways = async (req, res, next) => {
  try {
    const data = await Gateway.findAll({
      attributes: req.body.attributes || null,
    });

    const gateways = data.map((gateway) => ({
      ...gateway.dataValues,
      rates: JSON.parse(gateway.dataValues?.rates || "{}"),
    }));

    res.status(200).json({  gateways });
  } catch (error) {
    next(error);
  }
};
