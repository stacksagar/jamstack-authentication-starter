const Gateway = require("../../models/Gateway");

module.exports = delete_gateway = async (req, res, next) => {
  try {
    const id = req.params.id;
    await Gateway.destroy({ where: { id } });

    const all_gateways = await Gateway.findAll({ attributes: ["id", "rates"] });

    all_gateways.forEach((gateway) => {
      const rates = JSON.parse(gateway?.rates || "{}");

      console.log("ID ", id);
      console.log("before delete rates ", rates);
      delete rates[id];
      console.log("after delete rates ", rates);

      (async () => {
        await Gateway.update({ rates }, { where: { id: gateway?.id } });
      })();
    });

    res.status(200).json({
      message: "Gateway Deleted!",
    });
  } catch (error) {
    next(error);
  }
};
