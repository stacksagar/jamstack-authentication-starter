const multer = require("multer");
const { uid } = require("uid");
// Set the storage engine and file size limit
const storage = multer.diskStorage({
  destination: function (_req, _file, cb) {
    cb(null, "uploads/");
  },
  filename: function (req, file, cb) {
    const filename = `${uid()}-${file.originalname}`;
    const filelink = `${process.env.API}/${filename}`;
    req.filelink = filelink;
    cb(null, filename);
  },
});

const upload = multer({
  storage,
});

const SingleFileUpload = (req, res, next) => {
  upload.single("file")(req, res, (err) => {
    if (err) {
      // Handle multer errors
      if (err.code === "LIMIT_FILE_SIZE") {
        return res.status(400).json({ message: "File size limit exceeded" });
      }
      return res.status(400).json({ message: "Error uploading file" });
    }

    // If file is uploaded successfully, continue with the next middleware function
    next();
  });
};

module.exports = SingleFileUpload;
