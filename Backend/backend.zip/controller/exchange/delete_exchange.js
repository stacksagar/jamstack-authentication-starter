const Exchange = require("../../models/Exchange");
module.exports = delete_exchange = async (req, res, next) => {
  try {
    await Exchange.destroy({ where: { id: req.query.id } });

    res.status(200).json({ message: "Exchange Deleted!" });
  } catch (error) {
    next(error);
  }
};
