const express = require("express");
const Page_controllers = require("../controller/Page_controllers");
const router = express.Router();

router.post("/", Page_controllers.create);
router.get("/", Page_controllers.read);
router.get("/:page_url_name", Page_controllers.readSinglePage);
router.put("/", Page_controllers.update);
router.delete("/", Page_controllers.delete);

module.exports = pageRoutes = router;
