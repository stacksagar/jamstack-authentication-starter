const { DataTypes: types } = require("sequelize");
const sequelize = require("../database/connection");

const Review = sequelize.define("Review", {
  rating: {
    type: types.INTEGER,
    allowNull: false,
  },

  content: {
    type: types.STRING,
    allowNull: false,
  },
});

module.exports = Review;
