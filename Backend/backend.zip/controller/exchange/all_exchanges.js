const Exchange = require("../../models/Exchange");
const Gateway = require("../../models/Gateway");
const User = require("../../models/User");
module.exports = create_exchange = async (req, res, next) => {
  try {
    const status = req?.query?.status;
    const user_id = Number(req?.query?.user_id);
    const limit = Number(req?.query?.limit);
    const page = Number(req?.query?.page);

    const sort = req?.query?.sort;
    const order = req?.query?.order;

    const sortBy = (typeof sort === "object" ? sort[0] : sort || "")
      ?.toLowerCase()
      ?.trim();

    const orderBy = (typeof order === "object" ? order[0] : order || "")
      ?.toLowerCase()
      ?.trim();

    const offset = limit * (page - 1);

    const conditions = {
      where: {},
      order: [],
      include: [
        {
          model: Gateway,
          as: "sentGateway",
          attributes: ["id", "name", "logo", "currency"],
        },
        {
          model: Gateway,
          as: "receiveGateway",
          attributes: ["id", "name", "logo", "currency"],
        },
        { model: User, as: "user", attributes: ["id", "name"] },
      ],
    };

    if (user_id) {
      conditions.where.user_id = user_id;
    }

    if (page && limit) {
      conditions.offset = offset;
      conditions.limit = limit;
    }

    if (status) {
      conditions.where.status = status;
    }

    if (
      (sortBy === "id" ||
        sortBy === "sent_amount" ||
        sortBy === "receive_amount") &&
      (orderBy === "ascending" || orderBy === "descending")
    ) {
      conditions.order.push([sortBy, orderBy === "ascending" ? "ASC" : "DESC"]);
    }

    const exchanges = await Exchange.findAndCountAll({
      ...conditions,
    });

    res.status(201).json({
      totalPages: Math.ceil(exchanges.count / limit),
      totalItems: exchanges.count,
      currentPage: page,
      exchanges: exchanges.rows,
    });
  } catch (error) {
    next(error);
  }
};
