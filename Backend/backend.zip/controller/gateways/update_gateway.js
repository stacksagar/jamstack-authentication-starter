const Gateway = require("../../models/Gateway");

module.exports = update_gateway = async (req, res, next) => {
  try {
    await Gateway.update(req.body, {
      where: {
        id: req.params.id,
      },
    });

    const found = await Gateway.findOne({ where: { id: req.params.id } });

    const gateway = {
      ...found.dataValues,
      rates: JSON.parse(found.dataValues?.rates || "{}"),
    };

    res.status(200).json({
      gateway,
    });
  } catch (error) {
    next(error);
  }
};
